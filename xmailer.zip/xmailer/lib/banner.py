def main():
    from colorama import init, Fore, Back, Style
    init(autoreset=True)

    print (Style.BRIGHT + Fore.YELLOW + " `YMM'   `MP' " + Fore.GREEN + "`7MMM.     ,MMF'           db  `7MM                    ")
    print (Style.BRIGHT + Fore.YELLOW + "   VMb.  ,P   " + Fore.GREEN + "  MMMb    dPMM                   MM                    ")
    print (Style.BRIGHT + Fore.YELLOW + "    `MM.M'    " + Fore.GREEN + """  M YM   ,M MM   ,6"Yb.  `7MM    MM   .gP"Ya  `7Mb,od8 """)
    print (Style.BRIGHT + Fore.YELLOW + "      MMb     " + Fore.GREEN + """  M  Mb  M' MM  8)   MM    MM    MM  ,M'   Yb   MM' "' """)
    print (Style.BRIGHT + Fore.YELLOW + "    ,M'`Mb.   " + Fore.GREEN + '''  M  YM.P'  MM   ,pm9MM    MM    MM  8M""""""   MM     ''')
    print (Style.BRIGHT + Fore.YELLOW + "   ,P   `MM.  " + Fore.GREEN + "  M  `YM'   MM  8M   MM    MM    MM  YM.    ,   MM     ")
    print (Style.BRIGHT + Fore.YELLOW + " .MM:.  .:MMa." + Fore.GREEN + ".JML. `'  .JMML.`Moo9^Yo..JMML..JMML. `Mbmmd' .JMML.   ")
    print (Style.BRIGHT + Fore.GREEN + "====================================================================" )
    print (Style.BRIGHT + Fore.RED + " DISCLAIMER : Developer are not responsible for the uses of XMailer"  )
    print (Style.BRIGHT + Fore.BLUE + "                - Hilmi Azizi | hilmiazizi19@gmail.com -")
    print (Style.BRIGHT + Fore.GREEN + "====================================================================" )
    print ""
